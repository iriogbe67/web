# Pure CSS Tic-tac-toe

A Pen created on CodePen.io. Original URL: [https://codepen.io/ziga-miklic/pen/QWrGyW](https://codepen.io/ziga-miklic/pen/QWrGyW).

I have seen demos of pure CSS Tic-tac-toe games, but I was unable to find a version that truly works. If I have missed it, please send me link, so I can see how another dev has created it.